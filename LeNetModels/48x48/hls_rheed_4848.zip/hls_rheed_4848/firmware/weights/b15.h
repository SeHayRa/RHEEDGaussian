//Numpy array shape [5]
//Min -0.216078698635
//Max 0.241996318102
//Number of zeros 0

#ifndef B15_H_
#define B15_H_

#ifndef __SYNTHESIS__
model_default_t b15[5];
#else
model_default_t b15[5] = {-0.0814970732, -0.2160786986, 0.0214967839, -0.1074061692, 0.2419963181};
#endif

#endif
