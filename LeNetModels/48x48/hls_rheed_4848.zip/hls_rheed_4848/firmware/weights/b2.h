//Numpy array shape [6]
//Min -0.109640628099
//Max 0.177321434021
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[6];
#else
model_default_t b2[6] = {-2.0285744667, -1.5339034796, -1.9609680176, 2.1495285034, 2.2058105469, -0.0479650497};
#endif

#endif
